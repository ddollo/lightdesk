package com.ddollo.lightdesk;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class WidgetSyncWorker extends Worker {
    public WidgetSyncWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        return LightdeskWidget.refreshNow(getApplicationContext()) ? Result.success() : Result.retry();
    }
}
