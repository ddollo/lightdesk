package com.ddollo.lightdesk;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final String APP_URL = "https://ddollo.github.io/lightdesk/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView webView = findViewById(R.id.webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new WidgetBridge(this), "AndroidWidget");
        webView.loadUrl(APP_URL);
    }

    @Override
    public void onBackPressed() {
        WebView webView = findViewById(R.id.webview);
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private static class WidgetBridge {
        private final Context context;
        private final SharedPreferences prefs;

        WidgetBridge(Context context) {
            this.context = context.getApplicationContext();
            this.prefs = this.context.getSharedPreferences("lightdesk_widget", Context.MODE_PRIVATE);
        }

        @JavascriptInterface
        public void saveSession(String accessToken, String refreshToken) {
            prefs.edit()
                    .putString("access_token", accessToken)
                    .putString("refresh_token", refreshToken)
                    .apply();
        }

        @JavascriptInterface
        public void clearSession() {
            prefs.edit().remove("access_token").remove("refresh_token").apply();
        }

        @JavascriptInterface
        public void syncTasks(String json) {
            prefs.edit().putString("selected_tasks", json).apply();
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, LightdeskWidget.class));
            LightdeskWidget.updateAll(context, manager, ids, false);
        }
    }
}
