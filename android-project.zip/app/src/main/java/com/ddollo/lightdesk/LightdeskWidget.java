package com.ddollo.lightdesk;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LightdeskWidget extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "com.ddollo.lightdesk.REFRESH_WIDGET";
    private static final String BASE = "https://jrblfeqkaboahefzevwq.supabase.co";
    private static final String KEY = "sb_publishable_eP_R6Pau5NGxLuBlOQhFCw_IfhVMnAw";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        updateAll(context, manager, appWidgetIds, true);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, LightdeskWidget.class));
            updateAll(context, manager, ids, true);
        }
    }

    public static void updateAll(Context context, AppWidgetManager manager, int[] ids, boolean fetch) {
        for (int id : ids) render(context, manager, id, null, fetch);
        if (fetch) refreshFromServer(context, manager, ids);
    }

    private static void render(Context context, AppWidgetManager manager, int id, String message, boolean loading) {
        SharedPreferences prefs = context.getSharedPreferences("lightdesk_widget", Context.MODE_PRIVATE);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_lightdesk);
        views.setTextViewText(R.id.widget_date, new SimpleDateFormat("M월 d일 EEEE", Locale.KOREAN).format(new Date()));

        SpannableStringBuilder body = buildBody(prefs.getString("selected_tasks", "[]"));
        if (message != null) views.setTextViewText(R.id.widget_tasks, message);
        else if (body.length() == 0) views.setTextViewText(R.id.widget_tasks, "앱에서 □를 눌러\n위젯에 표시할 업무를 선택하세요.");
        else views.setTextViewText(R.id.widget_tasks, body);

        views.setViewVisibility(R.id.widget_loading, loading ? View.VISIBLE : View.GONE);

        Intent open = new Intent(context, MainActivity.class);
        PendingIntent openIntent = PendingIntent.getActivity(context, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, openIntent);

        Intent refresh = new Intent(context, LightdeskWidget.class).setAction(ACTION_REFRESH);
        PendingIntent refreshIntent = PendingIntent.getBroadcast(context, 1, refresh, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_refresh, refreshIntent);
        manager.updateAppWidget(id, views);
    }

    private static SpannableStringBuilder buildBody(String json) {
        SpannableStringBuilder out = new SpannableStringBuilder();
        try {
            JSONArray array = new JSONArray(json);
            Map<String, List<JSONObject>> groups = new LinkedHashMap<>();
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                if (item.optBoolean("completed", false)) continue;
                String category = item.optString("category", "기타");
                groups.computeIfAbsent(category, key -> new ArrayList<>()).add(item);
            }
            for (Map.Entry<String, List<JSONObject>> entry : groups.entrySet()) {
                if (out.length() > 0) out.append("\n");
                int headingStart = out.length();
                out.append(entry.getKey()).append("\n");
                out.setSpan(new StyleSpan(Typeface.BOLD), headingStart, out.length() - 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                for (JSONObject item : entry.getValue()) {
                    int start = out.length();
                    out.append("○  ").append(item.optString("title", "")).append("\n");
                    if (item.optInt("priority", 2) == 1) {
                        out.setSpan(new StyleSpan(Typeface.BOLD), start, out.length() - 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                }
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static void refreshFromServer(Context context, AppWidgetManager manager, int[] ids) {
        SharedPreferences prefs = context.getSharedPreferences("lightdesk_widget", Context.MODE_PRIVATE);
        String token = prefs.getString("access_token", "");
        String cached = prefs.getString("selected_tasks", "[]");
        if (token.isEmpty()) {
            for (int id : ids) render(context, manager, id, "앱에서 먼저 로그인해 주세요.", false);
            return;
        }

        EXECUTOR.execute(() -> {
            try {
                JSONArray selected = new JSONArray(cached);
                if (selected.length() == 0) throw new IllegalStateException("empty");
                Map<String, String> categories = new LinkedHashMap<>();
                List<String> taskIds = new ArrayList<>();
                for (int i = 0; i < selected.length(); i++) {
                    JSONObject item = selected.getJSONObject(i);
                    String taskId = item.optString("id");
                    taskIds.add(taskId);
                    categories.put(taskId, item.optString("category", "기타"));
                }

                String endpoint = BASE + "/rest/v1/lightdesk_tasks?select=id,title,priority,completed&id=in.(" + String.join(",", taskIds) + ")";
                HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
                connection.setRequestProperty("apikey", KEY);
                connection.setRequestProperty("Authorization", "Bearer " + token);
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(8000);
                if (connection.getResponseCode() != 200) throw new IllegalStateException("sync");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) response.append(line);
                reader.close();

                JSONArray fresh = new JSONArray(response.toString());
                for (int i = 0; i < fresh.length(); i++) {
                    JSONObject item = fresh.getJSONObject(i);
                    item.put("category", categories.getOrDefault(item.optString("id"), "기타"));
                }
                prefs.edit().putString("selected_tasks", fresh.toString()).apply();
                new Handler(Looper.getMainLooper()).post(() -> {
                    for (int id : ids) render(context, manager, id, null, false);
                });
            } catch (Exception error) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    SpannableStringBuilder cachedBody = buildBody(cached);
                    String message = cachedBody.length() == 0 ? "표시할 업무를 앱에서 선택하세요." : null;
                    for (int id : ids) render(context, manager, id, message, false);
                });
            }
        });
    }
}
