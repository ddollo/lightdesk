package com.ddollo.lightdesk;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.BroadcastReceiver.PendingResult;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LightdeskWidget extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "com.ddollo.lightdesk.REFRESH_WIDGET";
    private static final String BASE = "https://rrhvcotzvyzypusapkpy.supabase.co";
    private static final String KEY = "sb_publishable_JyzZo3tYGxuiy7hO9-rS7w_wS4y2pte";
    private static final long AUTO_REFRESH_MS = 60_000L;
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        scheduleAutoRefresh(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) alarm.cancel(refreshIntent(context, 2));
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        scheduleAutoRefresh(context);
        updateAll(context, manager, appWidgetIds, true, goAsync());
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, LightdeskWidget.class));
            updateAll(context, manager, ids, true, goAsync());
        }
    }

    private static PendingIntent refreshIntent(Context context, int requestCode) {
        Intent refresh = new Intent(context, LightdeskWidget.class).setAction(ACTION_REFRESH);
        return PendingIntent.getBroadcast(context, requestCode, refresh, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void scheduleAutoRefresh(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) {
            alarm.setInexactRepeating(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + AUTO_REFRESH_MS, AUTO_REFRESH_MS, refreshIntent(context, 2));
        }
    }

    public static void updateAll(Context context, AppWidgetManager manager, int[] ids, boolean fetch) {
        updateAll(context, manager, ids, fetch, null);
    }

    private static void updateAll(Context context, AppWidgetManager manager, int[] ids, boolean fetch, PendingResult pendingResult) {
        for (int id : ids) render(context, manager, id, null, fetch);
        if (fetch) refreshFromServer(context, manager, ids, pendingResult);
        else if (pendingResult != null) pendingResult.finish();
    }

    private static void render(Context context, AppWidgetManager manager, int id, String message, boolean loading) {
        SharedPreferences prefs = context.getSharedPreferences("lightdesk_widget", Context.MODE_PRIVATE);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_lightdesk);
        views.setTextViewText(R.id.widget_date, new SimpleDateFormat("M월 d일 EEEE", Locale.KOREAN).format(new Date()));

        SpannableStringBuilder body = buildBody(prefs.getString("selected_tasks", "[]"));
        if (message != null) views.setTextViewText(R.id.widget_tasks, message);
        else if (body.length() == 0) views.setTextViewText(R.id.widget_tasks, "앱에서 □를 눌러\n위젯에 표시할 업무를 선택하세요.");
        else views.setTextViewText(R.id.widget_tasks, body);

        views.setViewVisibility(R.id.widget_loading, loading ? View.VISIBLE : View.GONE);
        PendingIntent openIntent = PendingIntent.getActivity(context, 0, new Intent(context, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, openIntent);
        views.setOnClickPendingIntent(R.id.widget_refresh, refreshIntent(context, 1));
        manager.updateAppWidget(id, views);
    }

    private static SpannableStringBuilder buildBody(String json) {
        SpannableStringBuilder out = new SpannableStringBuilder();
        try {
            JSONArray array = new JSONArray(json);
            Map<String, List<JSONObject>> groups = new LinkedHashMap<>();
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                if (item.optBoolean("completed", false)) continue;
                String category = item.optString("category", "기타");
                groups.computeIfAbsent(category, key -> new ArrayList<>()).add(item);
            }
            for (Map.Entry<String, List<JSONObject>> entry : groups.entrySet()) {
                if (out.length() > 0) out.append("\n");
                int headingStart = out.length();
                out.append(entry.getKey()).append("\n");
                out.setSpan(new StyleSpan(Typeface.BOLD), headingStart, out.length() - 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                for (JSONObject item : entry.getValue()) {
                    int start = out.length();
                    out.append("○  ").append(item.optString("title", "")).append("\n");
                    if (item.optInt("priority", 2) == 1) out.setSpan(new StyleSpan(Typeface.BOLD), start, out.length() - 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static void refreshFromServer(Context context, AppWidgetManager manager, int[] ids, PendingResult pendingResult) {
        SharedPreferences prefs = context.getSharedPreferences("lightdesk_widget", Context.MODE_PRIVATE);
        String cached = prefs.getString("selected_tasks", "[]");
        EXECUTOR.execute(() -> {
            try {
                JSONArray categoriesJson = getJsonArray(BASE + "/rest/v1/lightdesk_categories?select=id,name");
                Map<String, String> categories = new LinkedHashMap<>();
                for (int i = 0; i < categoriesJson.length(); i++) {
                    JSONObject category = categoriesJson.getJSONObject(i);
                    categories.put(category.optString("id"), category.optString("name", "기타"));
                }

                JSONArray fresh = getJsonArray(BASE + "/rest/v1/lightdesk_tasks?select=id,title,priority,completed,category_id&show_in_widget=eq.true&order=position.asc,created_at.asc");
                for (int i = 0; i < fresh.length(); i++) {
                    JSONObject item = fresh.getJSONObject(i);
                    item.put("category", categories.getOrDefault(item.optString("category_id"), "기타"));
                }
                prefs.edit().putString("selected_tasks", fresh.toString()).apply();
                for (int id : ids) render(context, manager, id, null, false);
            } catch (Exception error) {
                String message = buildBody(cached).length() == 0 ? "서버 연결을 확인해 주세요." : null;
                for (int id : ids) render(context, manager, id, message, false);
            } finally {
                if (pendingResult != null) pendingResult.finish();
            }
        });
    }

    private static JSONArray getJsonArray(String endpoint) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        connection.setRequestProperty("apikey", KEY);
        connection.setRequestProperty("Authorization", "Bearer " + KEY);
        connection.setConnectTimeout(8000);
        connection.setReadTimeout(8000);
        if (connection.getResponseCode() != 200) throw new IllegalStateException("sync");
        StringBuilder response = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) response.append(line);
        }
        connection.disconnect();
        return new JSONArray(response.toString());
    }
}
