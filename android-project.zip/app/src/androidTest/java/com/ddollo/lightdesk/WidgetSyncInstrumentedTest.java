package com.ddollo.lightdesk;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.Manifest;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.widget.TextView;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class WidgetSyncInstrumentedTest {
    @Test
    public void widgetProviderAndLiveSyncWorkOnAndroid() throws Exception {
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();

        assertEquals(
                PackageManager.PERMISSION_GRANTED,
                context.checkSelfPermission(Manifest.permission.INTERNET)
        );

        ComponentName widget = new ComponentName(context, LightdeskWidget.class);
        assertTrue(context.getPackageManager().getReceiverInfo(widget, 0).exported);

        List<ResolveInfo> providers = context.getPackageManager().queryBroadcastReceivers(
                new android.content.Intent("android.appwidget.action.APPWIDGET_UPDATE").setPackage(context.getPackageName()),
                0
        );
        assertTrue(providers.stream().anyMatch(info -> info.activityInfo.name.equals(LightdeskWidget.class.getName())));
        assertTrue("Supabase widget fetch failed on Android", LightdeskWidget.refreshNow(context));
        String cached = context.getSharedPreferences("lightdesk_widget", Context.MODE_PRIVATE)
                .getString("selected_tasks", "[]");
        JSONArray tasks = new JSONArray(cached);
        assertTrue("No widget-selected task reached Android", tasks.length() > 0);

        JSONObject first = tasks.getJSONObject(0);
        assertTrue(first.optString("title").length() > 0);
        assertTrue(first.optString("category").length() > 0);

        AppWidgetHost host = new AppWidgetHost(context, 24680);
        int widgetId = host.allocateAppWidgetId();
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            assertTrue("Emulator could not bind the real widget", manager.bindAppWidgetIdIfAllowed(widgetId, widget));
            AppWidgetProviderInfo providerInfo = manager.getAppWidgetInfo(widgetId);
            assertNotNull(providerInfo);

            final AppWidgetHostView[] hostView = new AppWidgetHostView[1];
            InstrumentationRegistry.getInstrumentation().runOnMainSync(() -> {
                host.startListening();
                hostView[0] = host.createView(context, widgetId, providerInfo);
            });

            assertTrue(LightdeskWidget.refreshNow(context));
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            Thread.sleep(500);

            TextView taskText = hostView[0].findViewById(R.id.widget_tasks);
            assertNotNull(taskText);
            assertTrue(
                    "The bound home-screen widget did not render the selected task",
                    taskText.getText().toString().contains(first.optString("title"))
            );
        } finally {
            host.stopListening();
            host.deleteAppWidgetId(widgetId);
        }
    }
}
