package com.ddollo.lightdesk;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.work.WorkManager;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class WidgetSyncInstrumentedTest {
    @Test
    public void widgetProviderAndLiveSyncWorkOnAndroid() throws Exception {
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();

        assertEquals(
                PackageManager.PERMISSION_GRANTED,
                context.checkSelfPermission(Manifest.permission.INTERNET)
        );

        ComponentName widget = new ComponentName(context, LightdeskWidget.class);
        assertTrue(context.getPackageManager().getReceiverInfo(widget, 0).exported);

        List<ResolveInfo> providers = context.getPackageManager().queryBroadcastReceivers(
                new android.content.Intent("android.appwidget.action.APPWIDGET_UPDATE").setPackage(context.getPackageName()),
                0
        );
        assertTrue(providers.stream().anyMatch(info -> info.activityInfo.name.equals(LightdeskWidget.class.getName())));
        assertNotNull(WorkManager.getInstance(context));

        assertTrue("Supabase widget fetch failed on Android", LightdeskWidget.refreshNow(context));
        String cached = context.getSharedPreferences("lightdesk_widget", Context.MODE_PRIVATE)
                .getString("selected_tasks", "[]");
        JSONArray tasks = new JSONArray(cached);
        assertTrue("No widget-selected task reached Android", tasks.length() > 0);

        JSONObject first = tasks.getJSONObject(0);
        assertTrue(first.optString("title").length() > 0);
        assertTrue(first.optString("category").length() > 0);
    }
}
