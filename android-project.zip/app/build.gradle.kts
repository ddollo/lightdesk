plugins {
    id("com.android.application")
}

android {
    namespace = "com.ddollo.lightdesk"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ddollo.lightdesk"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
